import hashlib, hmac, time
from urllib.parse import parse_qsl
from fastapi import Header, HTTPException
from .config import settings

def validate_init_data(init_data: str) -> dict:
    pairs = dict(parse_qsl(init_data, keep_blank_values=True))
    received_hash = pairs.pop("hash", None)
    if not received_hash:
        raise HTTPException(401, "Telegram initData hash missing")
    auth_date = int(pairs.get("auth_date", "0"))
    if time.time() - auth_date > 86400:
        raise HTTPException(401, "Telegram initData expired")
    data_check = "\n".join(f"{k}={pairs[k]}" for k in sorted(pairs))
    secret = hmac.new(b"WebAppData", settings.bot_token.encode(), hashlib.sha256).digest()
    calculated = hmac.new(secret, data_check.encode(), hashlib.sha256).hexdigest()
    if not hmac.compare_digest(calculated, received_hash):
        raise HTTPException(401, "Invalid Telegram initData")
    return pairs

async def telegram_user(x_telegram_init_data: str = Header(default="")):
    import json
    data = validate_init_data(x_telegram_init_data)
    if not data.get("user"):
        raise HTTPException(401, "Telegram user missing")
    return json.loads(data["user"])
