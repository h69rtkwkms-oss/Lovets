def matches(listing, filters: dict) -> bool:
    def le(value, key): return value is None or filters.get(key) is None or value <= float(filters[key])
    def ge(value, key): return value is None or filters.get(key) is None or value >= float(filters[key])
    if filters.get("price_max") is not None and not le(float(listing.price) if listing.price is not None else None, "price_max"): return False
    if filters.get("price_min") is not None and not ge(float(listing.price) if listing.price is not None else None, "price_min"): return False
    if filters.get("year_min") is not None and not ge(listing.year, "year_min"): return False
    if filters.get("year_max") is not None and not le(listing.year, "year_max"): return False
    if filters.get("mileage_max") is not None and not le(listing.mileage, "mileage_max"): return False
    if filters.get("area_min") is not None and not ge(float(listing.area) if listing.area is not None else None, "area_min"): return False
    if filters.get("rooms_min") is not None and not ge(listing.rooms, "rooms_min"): return False
    if filters.get("rooms_max") is not None and not le(listing.rooms, "rooms_max"): return False
    city = filters.get("city")
    if city and listing.city and city.lower() not in listing.city.lower(): return False
    region = filters.get("region")
    if region and listing.region and region.lower() not in listing.region.lower(): return False
    text = (filters.get("text") or "").strip().lower()
    if text and text not in (listing.title + " " + (listing.description or "")).lower(): return False
    return True
