from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    bot_token: str
    webapp_url: str = "http://localhost:5173"
    database_url: str = "postgresql+asyncpg://lovets:lovets@db:5432/lovets"
    redis_url: str = "redis://redis:6379/0"
    poll_seconds: int = 60
    free_search_limit: int = 2
    pro_search_limit: int = 20
    max_search_limit: int = 100
    pro_stars: int = 299
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

settings = Settings()
