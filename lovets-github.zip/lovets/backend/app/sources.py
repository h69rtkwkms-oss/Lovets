from dataclasses import dataclass, field
from datetime import datetime

@dataclass
class NormalizedListing:
    source: str
    external_id: str
    category: str
    title: str
    url: str
    city: str | None = None
    region: str | None = None
    price: float | None = None
    year: int | None = None
    mileage: int | None = None
    area: float | None = None
    rooms: int | None = None
    description: str | None = None
    attributes: dict = field(default_factory=dict)
    images: list = field(default_factory=list)

class SourceAdapter:
    name = "base"
    async def fetch(self) -> list[NormalizedListing]:
        raise NotImplementedError

class DemoAdapter(SourceAdapter):
    name = "demo"
    async def fetch(self):
        return [
            NormalizedListing("demo", "auto-1", "auto", "Toyota Camry 2020", "https://example.com/auto-1", "Москва", "Москва", 1590000, 2020, 82000, description="Автомат, бензин"),
            NormalizedListing("demo", "realty-1", "realty", "2-комнатная квартира 54 м²", "https://example.com/realty-1", "Москва", "Москва", 16500000, area=54, rooms=2, description="10 минут до метро"),
        ]

# Add production adapters here. Use official APIs, licensed feeds, partner exports,
# or another source method you are authorized to use. Keep source-specific code isolated.
ADAPTERS = [DemoAdapter()]
