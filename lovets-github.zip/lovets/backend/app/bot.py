import asyncio
from aiogram import Bot, Dispatcher, types
from aiogram.filters import CommandStart, Command
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton, WebAppInfo
from aiogram import F
from .db import SessionLocal
from .models import User
from sqlalchemy import select
from .config import settings

async def main():
    bot=Bot(settings.bot_token)
    dp=Dispatcher()
    @dp.message(CommandStart())
    async def start(message: types.Message):
        kb=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="🔎 Открыть Радар", web_app=WebAppInfo(url=settings.webapp_url))]])
        await message.answer("<b>РАДАР</b>\n\nЗадай условия — Радар будет искать подходящие авто и квартиры и сообщать о новых предложениях.", parse_mode="HTML", reply_markup=kb)
    @dp.message(Command("app"))
    async def app(message: types.Message):
        await message.answer("Открыть Радар", reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="🔎 Открыть", web_app=WebAppInfo(url=settings.webapp_url))]]))
    @dp.message(Command("help"))
    async def help_(message: types.Message): await message.answer("Создай поиск, включи уведомления и Радар будет мониторить подключённые источники.")
    @dp.pre_checkout_query()
    async def pre_checkout(query):
        await bot.answer_pre_checkout_query(query.id, ok=True)

    @dp.message(F.successful_payment)
    async def successful_payment(message: types.Message):
        payment=message.successful_payment
        if payment.invoice_payload.startswith("pro:"):
            async with SessionLocal() as s:
                user=(await s.execute(select(User).where(User.telegram_id==message.from_user.id))).scalar_one_or_none()
                if user:
                    user.plan="pro"
                    await s.commit()
            await message.answer("✅ ЛОВЕЦ PRO активирован. Новые лимиты и функции доступны сразу.")

    @dp.message(Command("paysupport"))
    async def pay(message: types.Message): await message.answer("Поддержка по оплате: напишите владельцу сервиса в поддержку.")
    await dp.start_polling(bot)

if __name__ == "__main__": asyncio.run(main())
