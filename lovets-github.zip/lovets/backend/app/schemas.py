from pydantic import BaseModel, Field
from typing import Literal

class SearchCreate(BaseModel):
    category: Literal["auto", "realty"]
    title: str = Field(min_length=1, max_length=255)
    filters: dict = {}

class SearchOut(SearchCreate):
    id: int
    active: bool
    model_config = {"from_attributes": True}

class ListingOut(BaseModel):
    id: int
    source: str
    title: str
    description: str | None
    url: str
    city: str | None
    region: str | None
    price: float | None
    year: int | None
    mileage: int | None
    area: float | None
    rooms: int | None
    attributes: dict
    images: list
    first_seen_at: str
