from fastapi import FastAPI, Depends, HTTPException
from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession
from .db import SessionLocal, init_db
from .models import User, Search, Listing, Favorite, HiddenListing
from .schemas import SearchCreate, SearchOut, ListingOut
from .auth import telegram_user
from .config import settings
from .matching import matches
from aiogram import Bot
from aiogram.types import LabeledPrice
import secrets

app = FastAPI(title="ЛОВЕЦ API", version="1.0.0")

async def db():
    async with SessionLocal() as s:
        yield s

@app.on_event("startup")
async def startup(): await init_db()

async def get_user(tg, session):
    uid = tg["id"]
    result = await session.execute(select(User).where(User.telegram_id == uid))
    user = result.scalar_one_or_none()
    if not user:
        user = User(telegram_id=uid, username=tg.get("username"), referral_code=secrets.token_urlsafe(8))
        session.add(user); await session.commit(); await session.refresh(user)
    return user

@app.post("/billing/pro")
async def billing_pro(tg=Depends(telegram_user)):
    bot = Bot(settings.bot_token)
    await bot.send_invoice(chat_id=tg["id"], title="ЛОВЕЦ PRO", description="Месячная подписка ЛОВЕЦ PRO", payload=f"pro:{tg['id']}", currency="XTR", prices=[LabeledPrice(label="ЛОВЕЦ PRO", amount=settings.pro_stars)], subscription_period=30*24*60*60)
    await bot.session.close()
    return {"ok": True, "stars": settings.pro_stars}

@app.get("/health")
async def health(): return {"ok": True}

@app.get("/me")
async def me(tg=Depends(telegram_user), session: AsyncSession=Depends(db)):
    u = await get_user(tg, session)
    count = await session.scalar(select(func.count(Search.id)).where(Search.user_id == u.id, Search.active == True))
    return {"id":u.id,"telegram_id":u.telegram_id,"username":u.username,"plan":u.plan,"referral_code":u.referral_code,"searches":count}

@app.get("/searches", response_model=list[SearchOut])
async def searches(tg=Depends(telegram_user), session: AsyncSession=Depends(db)):
    u = await get_user(tg, session)
    rows = (await session.execute(select(Search).where(Search.user_id==u.id).order_by(Search.id.desc()))).scalars().all()
    return rows

@app.post("/searches", response_model=SearchOut)
async def create_search(payload: SearchCreate, tg=Depends(telegram_user), session: AsyncSession=Depends(db)):
    u = await get_user(tg, session)
    limit = settings.free_search_limit if u.plan == "free" else settings.pro_search_limit if u.plan == "pro" else settings.max_search_limit
    current = await session.scalar(select(func.count(Search.id)).where(Search.user_id==u.id, Search.active==True))
    if current >= limit: raise HTTPException(402, f"Лимит активных поисков: {limit}")
    row = Search(user_id=u.id, category=payload.category, title=payload.title, filters=payload.filters)
    session.add(row); await session.commit(); await session.refresh(row)
    return row

@app.delete("/searches/{search_id}")
async def delete_search(search_id:int, tg=Depends(telegram_user), session:AsyncSession=Depends(db)):
    u=await get_user(tg,session); row=await session.get(Search,search_id)
    if not row or row.user_id!=u.id: raise HTTPException(404)
    row.active=False; await session.commit(); return {"ok":True}

@app.get("/listings", response_model=list[ListingOut])
async def listings(category:str|None=None, limit:int=50, tg=Depends(telegram_user), session:AsyncSession=Depends(db)):
    u=await get_user(tg,session)
    stmt=select(Listing).order_by(Listing.first_seen_at.desc()).limit(min(limit,100))
    if category: stmt=stmt.where(Listing.category==category)
    rows=(await session.execute(stmt)).scalars().all()
    hidden={x.listing_id for x in (await session.execute(select(HiddenListing).where(HiddenListing.user_id==u.id))).scalars().all()}
    return [x for x in rows if x.id not in hidden]

@app.post("/listings/{listing_id}/favorite")
async def favorite(listing_id:int, tg=Depends(telegram_user), session:AsyncSession=Depends(db)):
    u=await get_user(tg,session); session.add(Favorite(user_id=u.id,listing_id=listing_id)); await session.commit(); return {"ok":True}

@app.post("/listings/{listing_id}/hide")
async def hide(listing_id:int, tg=Depends(telegram_user), session:AsyncSession=Depends(db)):
    u=await get_user(tg,session); session.add(HiddenListing(user_id=u.id,listing_id=listing_id)); await session.commit(); return {"ok":True}
