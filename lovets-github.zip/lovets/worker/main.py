import asyncio
from datetime import datetime
from sqlalchemy import select
from sqlalchemy.ext.asyncio import create_async_engine, async_sessionmaker
from app.config import settings
from app.models import Listing, Search, User, ListingEvent
from app.sources import ADAPTERS
from app.matching import matches
from aiogram import Bot

engine=create_async_engine(settings.database_url,pool_pre_ping=True)
Session=async_sessionmaker(engine,expire_on_commit=False)
bot=Bot(settings.bot_token)

async def run_once():
    async with Session() as s:
        for adapter in ADAPTERS:
            for item in await adapter.fetch():
                q=await s.execute(select(Listing).where(Listing.source==item.source,Listing.external_id==item.external_id))
                row=q.scalar_one_or_none(); is_new=row is None
                old_price=float(row.current_price) if row and row.current_price is not None else None
                if not row:
                    row=Listing(source=item.source,external_id=item.external_id,category=item.category,title=item.title,url=item.url,city=item.city,region=item.region,price=item.price,year=item.year,mileage=item.mileage,area=item.area,rooms=item.rooms,description=item.description,attributes=item.attributes,images=item.images,current_price=item.price)
                    s.add(row); await s.flush()
                else:
                    row.last_seen_at=datetime.utcnow()
                    row.current_price=item.price
                    row.title=item.title; row.description=item.description
                    row.city=item.city; row.region=item.region
                if old_price is not None and item.price is not None and item.price < old_price:
                    s.add(ListingEvent(listing_id=row.id,event_type="price_drop",old_price=old_price,new_price=item.price))
                searches=(await s.execute(select(Search,User).join(User,User.id==Search.user_id).where(Search.active==True,Search.category==item.category))).all()
                for search,user in searches:
                    if matches(row,search.filters):
                        if is_new:
                            try: await bot.send_message(user.telegram_id,f"🚨 Новое объявление\n\n{row.title}\n💰 {item.price or '—'} ₽\n📍 {item.city or item.region or '—'}\n\n{row.url}")
                            except Exception: pass
        await s.commit()

async def main():
    while True:
        try: await run_once()
        except Exception as e: print("worker error",repr(e))
        await asyncio.sleep(settings.poll_seconds)

if __name__=='__main__': asyncio.run(main())
