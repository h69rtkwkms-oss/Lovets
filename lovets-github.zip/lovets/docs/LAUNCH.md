# Запуск ЛОВЕЦ

## 1. Telegram
1. Открой @BotFather.
2. `/newbot` → создай бота → сохрани BOT_TOKEN.
3. Создай HTTPS домен, например `https://lovets.example`.
4. В BotFather задай Main Mini App URL на `https://lovets.example`.
5. В `.env` укажи `BOT_TOKEN` и `WEBAPP_URL`.

## 2. Сервер
Нужен VPS/облако с Docker и HTTPS reverse proxy. Минимально для старта: 2 CPU, 4 GB RAM, 40+ GB SSD; для роста вынести PostgreSQL/Redis отдельно.

```bash
cp .env.example .env
nano .env
docker compose up -d --build
```

## 3. HTTPS
Mini App должен открываться по HTTPS в Telegram. Поставь Nginx/Caddy перед frontend и API. Локально для теста используй HTTPS tunnel.

## 4. Проверка
```bash
curl http://localhost:8000/health
```
Ожидается `{\"ok\":true}`.

Открой бота → `/start` → «Открыть Радар».

## 5. Демо-источник
Worker по умолчанию добавляет 2 тестовых объявления. Это позволяет проверить весь pipeline без внешнего сайта.

## 6. Реальные источники
Добавляй классы в `backend/app/sources.py`, реализуя `SourceAdapter.fetch()`. Каждый адаптер должен получать данные законным способом: официальный API, партнёрский feed, лицензированный экспорт или иной разрешённый канал. После этого нормализуй всё в `NormalizedListing`.

## 7. Платежи
Для цифрового сервиса внутри Telegram используй Telegram Stars. Реализуй invoice/subscription callbacks, сохрани payment charge id и обработай `/paysupport` и возвраты. Не подставляй банковскую оплату вместо Stars внутри Telegram Mini App для цифрового продукта.

## 8. Перед продом
- privacy policy;
- оферта/условия подписки;
- support contact;
- rate limits;
- резервные копии БД;
- мониторинг ошибок;
- логирование;
- защита admin endpoints;
- проверка юридических условий каждого источника;
- тестовые платежи;
- тест на дубли и повторные уведомления.
